package br.com.ailton.cadastro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCadastrar.setOnClickListener {
            var nome = pltNome.text.toString().trim()
            var sobrenome = pltSobrenome.text.toString().trim()
            var email = pltEmail.text.toString().trim()
            var telefone = pltTelefone.text.toString().trim()

            if(nome == "" || sobrenome == "" ||
                email == "" || telefone == "") {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_LONG).show()

            } else {
                // Pos cadastro
                txvCadastro.text = "$nome $sobrenome"
                Toast.makeText(this, "Cadastro efetuado com sucesso!", Toast.LENGTH_LONG).show()

            }
        }
    }
}
