package com.ailton.estacaohack

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cadastro.*
import kotlinx.android.synthetic.main.activity_cadastro.btnCadastro

class CadastroActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        //Lista de sexo
        val genero = this.resources.getStringArray(R.array.gender)

        //Criando o SharedPreferences
        val minhaPreferencia = getSharedPreferences("minha-preferencia", Context.MODE_PRIVATE)

        //Criando o Editor do SharedPreferences
        val meuEditor = minhaPreferencia.edit()

        //Criando o Adaptador do Spinner
        val adapterGenero = ArrayAdapter(this@CadastroActivity, android.R.layout.simple_spinner_dropdown_item, genero)

        //Adicionando a lista no Spinner
        spnSexo.adapter = adapterGenero

        btnCadastro.setOnClickListener {
            val nome = edtNome.text.toString().trim()
            val sobrenome = edtSobrenome.text.toString().trim()
            val email = edtEmail.text.toString().toLowerCase().trim()
            val senha = edtPassword.text.toString().trim()


            //Validar campos vazios
            if(nome.isEmpty() || sobrenome.isEmpty() || email.isEmpty() || senha.isEmpty()){
                Toast.makeText(this@CadastroActivity, getString(R.string.fillFields), Toast.LENGTH_SHORT).show()
            } else if(spnSexo.selectedItemPosition == 0){
                Toast.makeText(this@CadastroActivity, getString(R.string.fillGender), Toast.LENGTH_SHORT).show()
            } else {
                //
                meuEditor.putString("nome", nome)
                meuEditor.putString("sobrenome", sobrenome)
                meuEditor.putString("email", email)
                meuEditor.putString("senha", senha)
                meuEditor.putString("sexo", spnSexo.selectedItem.toString())

                Toast.makeText(this@CadastroActivity, getString(R.string.registerSuccess), Toast.LENGTH_SHORT).show()
                onBackPressed()
            }
        }

    }

}
