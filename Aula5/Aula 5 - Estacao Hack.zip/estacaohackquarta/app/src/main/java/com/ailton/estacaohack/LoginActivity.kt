package com.ailton.estacaohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //Criando o clique do Botão Entrar

        btnEntrar.setOnClickListener{

            // recuperando os valores digitados
            val usuario = edtUsuario.text.toString().trim()
            val senha = edtSenha.text.toString().trim()

            //Verificando se o usuário ou password estão corretos

            if(usuario.isEmpty()){
                txvResultado.text = getString(R.string.userEmpty)
            }else if(senha.isEmpty()){
                txvResultado.text = getString(R.string.passwordEmpty)
            }else if(usuario == ""){
                if(senha == ""){
                    txvResultado.text = getString(R.string.userLogged)
                }else{
                    txvResultado.text = getString(R.string.incorrectUser)
                }
            }else{
                txvResultado.text = getString(R.string.incorrectUser)
            }

        }

        btnCadastro.setOnClickListener {
            startActivity(Intent(this@LoginActivity,CadastroActivity::class.java))
        }
    }
}
