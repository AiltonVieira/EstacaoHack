package br.com.ailton.helloworld

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //findViewById<Button>(R.id.btnTraduzir).setOnClickListener {
        //    findViewById<TextView>(R.id.txvHello).text = "Olá Mundo!"
        //}

        btnTraduzir.setOnClickListener {
            if(txvHello.text == "Olá Mundo!")
                txvHello.text = "Hello World!"
            else txvHello.text = "Olá Mundo!"

            if(btnTraduzir.text == "Traduzir")
                btnTraduzir.text = "Translate"
            else btnTraduzir.text = "Traduzir"
        }
    }
}
