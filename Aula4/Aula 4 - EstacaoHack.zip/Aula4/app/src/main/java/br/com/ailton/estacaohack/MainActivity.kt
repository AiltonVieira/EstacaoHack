package br.com.ailton.estacaohack

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnEntrar.setOnClickListener{
            val login = edtLogin.text.toString().trim()
            val senha = edtSenha.text.toString().trim()

            if(login.isEmpty()){
                txvStatus.text = resources.getString(R.string.loginVazio)
            } else if(senha.isEmpty()) {
                txvStatus.text = resources.getString(R.string.senhaVazio)
            } else if(login == "Ailton" && senha == "1234") {
                txvStatus.text = resources.getString(R.string.usuarioLogado)
            } else {
                txvStatus.text = resources.getString(R.string.usuarioIncorreto)
            }
        }
    }
}
